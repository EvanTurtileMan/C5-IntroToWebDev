"use strict";

window.onload = function() {
    document.getElementById("grabPic").onclick = function() {
        document.getElementById("loadPic").innerHTML = `<img src=\"./53451-Cute-Dog.jpg\">`;
    };
};