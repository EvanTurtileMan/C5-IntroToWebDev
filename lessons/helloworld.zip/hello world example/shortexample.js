window.onload = function() {
    document.getElementById("example").innerHTML = `Hello World!`;
}