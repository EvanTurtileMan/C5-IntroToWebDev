"use strict";

window.onload = function() {
    document.getElementById("calculatorArea").innerHTML = `We will calculate 5 + 5`;

    document.getElementById("calculateRandom").onclick = function() {
        document.getElementById("calculatorArea").innerHTML = `We calculated it to ` + (5 + 5);
    }
}

